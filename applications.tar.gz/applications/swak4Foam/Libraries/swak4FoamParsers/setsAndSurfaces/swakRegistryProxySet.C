/*---------------------------------------------------------------------------*\
|                       _    _  _     ___                       | The         |
|     _____      ____ _| | _| || |   / __\__   __ _ _ __ ___    | Swiss       |
|    / __\ \ /\ / / _` | |/ / || |_ / _\/ _ \ / _` | '_ ` _ \   | Army        |
|    \__ \\ V  V / (_| |   <|__   _/ / | (_) | (_| | | | | | |  | Knife       |
|    |___/ \_/\_/ \__,_|_|\_\  |_| \/   \___/ \__,_|_| |_| |_|  | For         |
|                                                               | OpenFOAM    |
-------------------------------------------------------------------------------
License
    This file is part of swak4Foam.

    swak4Foam is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    swak4Foam is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with swak4Foam.  If not, see <http://www.gnu.org/licenses/>.

Contributors/Copyright:
    2012-2013, 2016-2018, 2023 Bernhard F.W. Gschaider <bgschaid@hfd-research.com>

 SWAK Revision: $Id$
\*---------------------------------------------------------------------------*/

#include "swakRegistryProxySet.H"
#include "dictionary.H"
#include "volFields.H"
#include "volPointInterpolation.H"
#include "addToRunTimeSelectionTable.H"
#include "fvMesh.H"

#include "SetsRepository.H"

// * * * * * * * * * * * * * * Static Data Members * * * * * * * * * * * * * //

namespace Foam
{
    defineTypeNameAndDebug(swakRegistryProxySet, 0);
    addToRunTimeSelectionTable(sampledSet, swakRegistryProxySet, word);
}

// * * * * * * * * * * * * * Private Member Functions  * * * * * * * * * * * //

// void Foam::swakRegistryProxySet::createGeometry()
// {
//     if (debug)
//     {
//         Pout<< "swakRegistryProxySet::createGeometry() - doing nothing"
//             << endl;
//     }
// }

Foam::sampledSet &Foam::swakRegistryProxySet::realSet()
{
    return SetsRepository::getRepository(
        mesh()
    ).getSet(
        setName_,
        static_cast<const fvMesh&>(mesh())
    );
}

const Foam::sampledSet &Foam::swakRegistryProxySet::realSet() const
{
    return SetsRepository::getRepository(
        mesh()
    ).getSet(
        setName_,
        static_cast<const fvMesh&>(mesh())
    );
}


// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

Foam::swakRegistryProxySet::swakRegistryProxySet
(
    const word& name,
    const polyMesh& mesh,
#ifdef FOAM_MESHSEARCH_CONST_SAMPLEDSET
    const meshSearch& search,
#else
    meshSearch& search,
#endif
    const dictionary& dict
)
:
    sampledSet(
        name,
        mesh,
        search,
        dict
    ),
    setName_(dict.lookup("setName"))
{
#ifdef FOAM_SET_WRITER_NOT_A_TEMPLATE
    setSamples(
        realSet().pointCoords(),
        realSet().segments(),
        realSet().cells(),
        realSet().faces()
    );
#else
    setSamples(
        realSet(),
        realSet().cells(),
        realSet().faces(),
        realSet().segments(),
        realSet().curveDist()
    );
#endif
}


// * * * * * * * * * * * * * * * * Destructor  * * * * * * * * * * * * * * * //

Foam::swakRegistryProxySet::~swakRegistryProxySet()
{}

#ifdef FOAM_SAMPLEDSET_NEEDS_REFPOINT
Foam::point Foam::swakRegistryProxySet::getRefPoint (const List< point > &pl) const
{
    return realSet().getRefPoint(pl);
}
#endif

// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //


// ************************************************************************* //
