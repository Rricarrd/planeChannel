/*---------------------------------------------------------------------------*\
|                       _    _  _     ___                       | The         |
|     _____      ____ _| | _| || |   / __\__   __ _ _ __ ___    | Swiss       |
|    / __\ \ /\ / / _` | |/ / || |_ / _\/ _ \ / _` | '_ ` _ \   | Army        |
|    \__ \\ V  V / (_| |   <|__   _/ / | (_) | (_| | | | | | |  | Knife       |
|    |___/ \_/\_/ \__,_|_|\_\  |_| \/   \___/ \__,_|_| |_| |_|  | For         |
|                                                               | OpenFOAM    |
-------------------------------------------------------------------------------
License
    This file is part of swak4Foam.

    swak4Foam is free software; you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation; either version 2 of the License, or (at your
    option) any later version.

    swak4Foam is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with swak4Foam; if not, write to the Free Software Foundation,
    Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA

Contributors/Copyright:
    2012-2014, 2016-2018, 2020-2022 Bernhard F.W. Gschaider <bgschaid@hfd-research.com>
    2019 Mark Olesen <Mark.Olesen@esi-group.com>

 SWAK Revision: $Id$
\*---------------------------------------------------------------------------*/

#include "swakExprString.H"

#include "CommonValueExpressionDriver.H"

namespace Foam {

// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

exprString::exprString()
:
    string()
{
    isValid();
}

exprString::exprString(const exprString &o)
:
    string(o)
{
    isValid();
}

// exprString::exprString(const string &o)
// :
//     string(o)
// {
//     isValid();
// }

// exprString::exprString(const std::string &o)
// :
//     string(o)
// {
//     isValid();
// }

exprString::exprString(const char *o)
:
    string(o)
{
    isValid();
}

exprString::exprString(
    Istream & in,
    const dictionary &dict
)
    :
    string(in)
{
    (*this)=CommonValueExpressionDriver::expandDictVariables(
        (*this),
        dict
    );
    isValid();
}

exprString::exprString(
    const string &in,
    const dictionary &dict
)
    :
    string(in)
{
    (*this)=CommonValueExpressionDriver::expandDictVariables(
        (*this),
        dict
    );
    isValid();
}

exprString::~exprString() {
}

// * * * * * * * * * * * * * * * Member Operators  * * * * * * * * * * * * * //

exprString exprString::toExpr(const string &o)
{
    exprString e;

    e.string::operator=(o);

    return e;
}

exprString &exprString::operator=(const string &o)
{
    string::operator=(o);
    isValid();
    return *this;
}

exprString &exprString::operator=(const exprString &o) {
    string::operator=(o);
    isValid();
    return *this;
}

bool exprString::isValid() {
    if(find('$')!=std::string::npos) {
        FatalErrorIn("exprString::isValid()")
            << "There is a '$' in " << *this
                << endl
                << exit(FatalError);

        return false;
    }
    return true;
}

// * * * * * * * * * * * * * * * Friend Functions  * * * * * * * * * * * * * //


// * * * * * * * * * * * * * * * Friend Operators  * * * * * * * * * * * * * //

} // namespace

// ************************************************************************* //
