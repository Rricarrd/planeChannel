/*---------------------------------------------------------------------------*\
|                       _    _  _     ___                       | The         |
|     _____      ____ _| | _| || |   / __\__   __ _ _ __ ___    | Swiss       |
|    / __\ \ /\ / / _` | |/ / || |_ / _\/ _ \ / _` | '_ ` _ \   | Army        |
|    \__ \\ V  V / (_| |   <|__   _/ / | (_) | (_| | | | | | |  | Knife       |
|    |___/ \_/\_/ \__,_|_|\_\  |_| \/   \___/ \__,_|_| |_| |_|  | For         |
|                                                               | OpenFOAM    |
-------------------------------------------------------------------------------
License
    This file is part of swak4Foam.

    swak4Foam is free software; you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation; either version 2 of the License, or (at your
    option) any later version.

    swak4Foam is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with swak4Foam; if not, write to the Free Software Foundation,
    Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA

Contributors/Copyright:
    2012-2013, 2016-2018, 2021 Bernhard F.W. Gschaider <bgschaid@hfd-research.com>

 SWAK Revision: $Id$
\*---------------------------------------------------------------------------*/

#include "ConcretePluginFunction.H"

namespace Foam {


// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

template<class DriverType>
ConcretePluginFunction<DriverType>::ConcretePluginFunction(
    const DriverType &parentDriver,
    const word &name,
    const word &returnType,
    const string &argumentSpecification
):
    CommonPluginFunction(
        parentDriver,
        name,
        returnType,
        argumentSpecification
    )
{
}

// * * * * * * * * * * * * * * * * Destructor  * * * * * * * * * * * * * * * //


// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

template<class DriverType>
autoPtr<ConcretePluginFunction<DriverType> > ConcretePluginFunction<DriverType>::New (
    const DriverType& driver,
    const word &name
)
{
    if(debug) {
        Info << "ConcretePluginFunction::New looking for "
            << name << " in "
#ifdef FOAM_HAS_SORTED_TOC
            << nameConstructorTablePtr_->sortedToc()
#else
            << nameConstructorTablePtr_->toc()
#endif
            << endl;
    }
    if(nameConstructorTablePtr_==NULL) {
        FatalErrorIn("ConcretePluginFunction<DriverType>::New")
            << "Constructor table of plugin functions for "
                << DriverType::typeName << " is not initialized"
                << endl
                << exit(FatalError);
        }
#ifdef FOAM_NO_FOO_CONSTRUCTOR_TABLE_TYPE_IN_RUNTIME_SELECTION
    auto
#else
    typename nameConstructorTable::iterator
#endif
        cstrIter =
        nameConstructorTablePtr_->find(name);
    if(cstrIter==nameConstructorTablePtr_->end()) {
        FatalErrorIn(
            "autoPtr<ConcretePluginFunction> ConcretePluginFunction<"+
            DriverType::typeName+">::New"
        ) << "Unknow plugin function " << name << endl
            << " Available functions are "
#ifdef FOAM_HAS_SORTED_TOC
            << nameConstructorTablePtr_->sortedToc()
#else
            << nameConstructorTablePtr_->toc()
#endif
                << endl
                << exit(FatalError);
    }
    return autoPtr<ConcretePluginFunction>
        (
            cstrIter()(driver,name)
        );
}

template<class DriverType>
bool ConcretePluginFunction<DriverType>::exists (
    const DriverType& driver,
    const word &name
)
{
    static bool firstCall=true;
    if(firstCall) {
        firstCall=false;

        if(nameConstructorTablePtr_==NULL) {
            WarningIn("ConcretePluginFunction<DriverType>::exists")
                << "Constructor table of plugin functions for "
                    << DriverType::typeName << " is not initialized"
                    << endl;
            return false;
        }
        if(nameConstructorTablePtr_->size()>0) {
            Info<< endl << "Loaded plugin functions for '"+
                DriverType::typeName+"':" << endl;
            wordList names(
#ifdef FOAM_HAS_SORTED_TOC
                nameConstructorTablePtr_->sortedToc()
#else
                nameConstructorTablePtr_->toc()
#endif
            );
            forAll(names,nameI)
            {
                const word &theName=names[nameI];
#ifdef FOAM_NO_FOO_CONSTRUCTOR_TABLE_TYPE_IN_RUNTIME_SELECTION
                auto
#else
                typename nameConstructorTable::iterator
#endif
                    iter =
                    nameConstructorTablePtr_->find(theName);
                Info << "  " << theName << ":" << endl
                    << "    " << iter()(driver,theName)->helpText() << endl;
            }

            Info << endl;
        }
    }

#ifdef FOAM_NO_FOO_CONSTRUCTOR_TABLE_TYPE_IN_RUNTIME_SELECTION
    auto
#else
    typename nameConstructorTable::iterator
#endif
        cstrIter =
        nameConstructorTablePtr_->find(name);

    return cstrIter!=nameConstructorTablePtr_->end();
}

// * * * * * * * * * * * * * * * Friend Operators  * * * * * * * * * * * * * //

} // namespace

// ************************************************************************* //
