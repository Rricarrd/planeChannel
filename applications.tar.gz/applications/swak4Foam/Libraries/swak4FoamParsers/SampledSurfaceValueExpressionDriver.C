/*---------------------------------------------------------------------------*\
|                       _    _  _     ___                       | The         |
|     _____      ____ _| | _| || |   / __\__   __ _ _ __ ___    | Swiss       |
|    / __\ \ /\ / / _` | |/ / || |_ / _\/ _ \ / _` | '_ ` _ \   | Army        |
|    \__ \\ V  V / (_| |   <|__   _/ / | (_) | (_| | | | | | |  | Knife       |
|    |___/ \_/\_/ \__,_|_|\_\  |_| \/   \___/ \__,_|_| |_| |_|  | For         |
|                                                               | OpenFOAM    |
-------------------------------------------------------------------------------
License
    This file is part of swak4Foam.

    swak4Foam is free software; you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation; either version 2 of the License, or (at your
    option) any later version.

    swak4Foam is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with swak4Foam; if not, write to the Free Software Foundation,
    Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA

Contributors/Copyright:
    2010-2013, 2016, 2018-2021 Bernhard F.W. Gschaider <bgschaid@hfd-research.com>

 SWAK Revision: $Id$
\*---------------------------------------------------------------------------*/

#include "SampledSurfaceValueExpressionDriver.H"
#include "SampledSurfaceValuePluginFunction.H"

#include "SurfacesRepository.H"

#include "addToRunTimeSelectionTable.H"

#include "sampledIsoSurface.H"

namespace Foam {

// * * * * * * * * * * * * * * Static Data Members * * * * * * * * * * * * * //

defineTypeNameAndDebug(SampledSurfaceValueExpressionDriver, 0);

word SampledSurfaceValueExpressionDriver::driverName_="surface";

addNamedToRunTimeSelectionTable(CommonValueExpressionDriver, SampledSurfaceValueExpressionDriver, dictionary, surface);
addNamedToRunTimeSelectionTable(CommonValueExpressionDriver, SampledSurfaceValueExpressionDriver, idName, surface);

#ifdef FOAM_HAS_SAMPLEDSURFACES_NAMESPACE
#define sampledIsoSurface sampledSurfaces::isoSurface
#endif

// * * * * * * * * * * * * * Private Member Functions  * * * * * * * * * * * //

void SampledSurfaceValueExpressionDriver::setDebug()
{
    if(debug>1) {
        if(sampledSurface::debug<1) {
            sampledSurface::debug=1;
        }
        if(sampledIsoSurface::debug<1) {
            sampledIsoSurface::debug=1;
        }
//         if(isoSurface::debug<1) {
//             isoSurface::debug=1;
//         }
    }
}

// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //


SampledSurfaceValueExpressionDriver::SampledSurfaceValueExpressionDriver(
    const sampledSurface &surf,
    const SampledSurfaceValueExpressionDriver& orig
)
:
        SubsetValueExpressionDriver(orig),
        //        theSurface_(surf.clone()),
        theSurface_(surf),
        interpolate_(orig.interpolate_),
        interpolationType_(orig.interpolationType_)
{
    setDebug();
}

SampledSurfaceValueExpressionDriver::SampledSurfaceValueExpressionDriver(
    sampledSurface &surf,
    bool autoInterpolate,
    bool warnAutoInterpolate
)
:
    SubsetValueExpressionDriver(autoInterpolate,warnAutoInterpolate),
    theSurface_(surf),
    interpolate_(false),
    interpolationType_("noInterpolationTypeSpecified1")
{
    setDebug();
}

SampledSurfaceValueExpressionDriver::SampledSurfaceValueExpressionDriver(
    const word &id,
    const fvMesh &mesh
)
:
    SubsetValueExpressionDriver(true,false),
    theSurface_(
        SurfacesRepository::getRepository(mesh).getSurface(
            id,
            mesh
        )
    ),
    interpolate_(false),
#ifndef FOAM_SAMPLEDSURFACE_SAMPLE_WANTS_INTERPOLATION
    interpolationType_("noInterpolationTypeSpecified2")
#else
    interpolationType_("cell")
#endif
{
    setDebug();
}

SampledSurfaceValueExpressionDriver::SampledSurfaceValueExpressionDriver(
    const dictionary& dict,
    const fvMesh&mesh
)
 :
    SubsetValueExpressionDriver(dict),
    theSurface_(
        SurfacesRepository::getRepository(mesh).getSurface(
            dict,
            mesh
        )
    ),
    interpolate_(dict.lookupOrDefault<bool>("interpolate",false)),
    interpolationType_(
#ifndef FOAM_SAMPLEDSURFACE_SAMPLE_WANTS_INTERPOLATION
        interpolate_
        ?
#endif
        word(dict.lookup("interpolationType"))
#ifndef FOAM_SAMPLEDSURFACE_SAMPLE_WANTS_INTERPOLATION
        :
        word("noInterpolationTypeSpecified")
#endif
    )
{
    setDebug();
}
// * * * * * * * * * * * * * * * * Destructor  * * * * * * * * * * * * * * * //

SampledSurfaceValueExpressionDriver::~SampledSurfaceValueExpressionDriver()
{}


// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

bool SampledSurfaceValueExpressionDriver::update()
{
    Dbug << "update() "
        << "needsUpdate: " << theSurface_.needsUpdate() << endl;

    if(theSurface_.needsUpdate()) {
        bool expired=const_cast<sampledSurface&>(theSurface_).expire();
        Dbug << "Expired: " << expired << endl;
    }
    bool updated=const_cast<sampledSurface &>(theSurface_).update(); // valgrind reports huge memory losses here

    Dbug << "Updated: " << updated << " " << this->size() << endl;

    return updated;
}

void SampledSurfaceValueExpressionDriver::updateIfNeeded()
{
    Dbug << "updateIfNeeded()" << endl;

    if(theSurface_.needsUpdate()) {
        Dbug << "Forcing an update" << endl;

        update();
    }
}

tmp<Field<scalar> > SampledSurfaceValueExpressionDriver::getScalarField(
    const word &name,bool oldTime
)
{
    return sampleOrInterpolateInternal<scalar,volScalarField,surfaceScalarField>
        (
            name,
            oldTime
        );
}

tmp<Field<vector> > SampledSurfaceValueExpressionDriver::getVectorField(
    const word &name,bool oldTime
)
{
    return sampleOrInterpolateInternal<vector,volVectorField,surfaceVectorField>
        (
            name,
            oldTime
        );
}

tmp<Field<tensor> > SampledSurfaceValueExpressionDriver::getTensorField(
    const word &name,bool oldTime
)
{
    return sampleOrInterpolateInternal<tensor,volTensorField,surfaceTensorField>
        (
            name,
            oldTime
        );
}

tmp<Field<symmTensor> > SampledSurfaceValueExpressionDriver::getSymmTensorField(
    const word &name,bool oldTime
)
{
    return sampleOrInterpolateInternal<symmTensor,volSymmTensorField,
                                       surfaceSymmTensorField>
        (
            name,
            oldTime
        );
}

tmp<Field<sphericalTensor> >
SampledSurfaceValueExpressionDriver::getSphericalTensorField(
    const word &name,bool oldTime
)
{
    return sampleOrInterpolateInternal<sphericalTensor,
                                       volSphericalTensorField,
                                       surfaceSphericalTensorField>
        (
            name,
            oldTime
        );
}

tmp<vectorField> SampledSurfaceValueExpressionDriver::makePositionField() const
{
    return theSurface_.Cf();
    // valgrind reports huge memory losses here
}

tmp<scalarField>
SampledSurfaceValueExpressionDriver::makeCellVolumeField() const
{
    FatalErrorIn("SampledSurfaceValueExpressionDriver::makeCellVolumeField()")
        << "faceZone knows nothing about cells"
            << endl
            << exit(FatalError);

    return tmp<scalarField>(
        new scalarField(0)
    );
}


// tmp<vectorField> SampledSurfaceValueExpressionDriver::makePointField()
// {
//     notImplemented("SampledSurfaceValueExpressionDriver::makePointField");
// }

tmp<scalarField>
SampledSurfaceValueExpressionDriver::makeFaceAreaMagField() const
{
    label mySize=this->size();
    label areaSize=theSurface_.magSf().size();
    Pbug << "SampledSurfaceValueExpressionDriver::makeFaceAreaMagField()"
        << " size: " << mySize << " magSf: "
        << areaSize
        << endl;

    if(mySize!=areaSize) {
        FatalErrorIn("SampledSurfaceValueExpressionDriver::makeFaceAreaMagField()")
            << "Size of magSf " << areaSize << " and size of the surface "
                << mySize << " differ."
                << endl << "Probably the surface changed and was not correctly recalculated (bug in Foam)"
            //                << endl << theSurface_.magSf()
                << endl
                << exit(FatalError);
    }
    return tmp<scalarField>(
        new scalarField(theSurface_.magSf())
    );
}

tmp<scalarField> SampledSurfaceValueExpressionDriver::makeFaceFlipField() const
{
    tmp<scalarField> result(new scalarField(this->size(),false));

    return result;
}

tmp<vectorField>
SampledSurfaceValueExpressionDriver::makeFaceNormalField() const
{
    return this->makeFaceAreaField()/this->makeFaceAreaMagField();
}

tmp<vectorField> SampledSurfaceValueExpressionDriver::makeFaceAreaField() const
{
    return tmp<vectorField>(
        new vectorField(theSurface_.Sf())
    );
}

autoPtr<CommonPluginFunction>
SampledSurfaceValueExpressionDriver::newPluginFunction(
    const word &name
) {
    return autoPtr<CommonPluginFunction>(
        SampledSurfaceValuePluginFunction::New(
            *this,
            name
        ).ptr()
    );
}

bool SampledSurfaceValueExpressionDriver::existsPluginFunction(
    const word &name
) {
    return SampledSurfaceValuePluginFunction::exists(
        *this,
        name
    );
}

tmp<scalarField> SampledSurfaceValueExpressionDriver::weightsNonPoint(
    label size
) const
{
    const label faceSize=this->size();
    bool isFace=(size==faceSize);
    reduce(isFace,andOp<bool>());

    if(!isFace) {
        Pout << "Expected size: " << size
            << " Face size: " << faceSize << endl;

        FatalErrorIn("SampledSurfaceValueExpressionDriver::weightsNonPoint")
            << "Can not construct weight field of the expected size. "
                << " For sizes on the processors see above"
                << endl
                << exit(FatalError);
    }

    return tmp<scalarField>(makeFaceAreaMagField());
}

label SampledSurfaceValueExpressionDriver::size() const
{
    Dbug << "size()" << endl;
    Dbug << "Needs update: " << theSurface_.needsUpdate() << endl;

    const_cast<SampledSurfaceValueExpressionDriver&>(*this).updateIfNeeded();

    return theSurface_.faces().size();
}

label SampledSurfaceValueExpressionDriver::pointSize() const
{
    Dbug << "pointSize()" << endl;

    const_cast<SampledSurfaceValueExpressionDriver&>(*this).updateIfNeeded();

    return theSurface_.points().size();
}

const fvMesh &SampledSurfaceValueExpressionDriver::mesh() const
{
    Dbug << "mesh()" << endl;

    //        return dynamicCast<const fvMesh&>(faceZone_.zoneMesh().mesh()); // doesn't work with gcc 4.2
    return dynamic_cast<const fvMesh&>(theSurface_.mesh());
}

// ************************************************************************* //

} // namespace
