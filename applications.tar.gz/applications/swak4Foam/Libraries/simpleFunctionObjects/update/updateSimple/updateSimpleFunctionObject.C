/*---------------------------------------------------------------------------*\
|                       _    _  _     ___                       | The         |
|     _____      ____ _| | _| || |   / __\__   __ _ _ __ ___    | Swiss       |
|    / __\ \ /\ / / _` | |/ / || |_ / _\/ _ \ / _` | '_ ` _ \   | Army        |
|    \__ \\ V  V / (_| |   <|__   _/ / | (_) | (_| | | | | | |  | Knife       |
|    |___/ \_/\_/ \__,_|_|\_\  |_| \/   \___/ \__,_|_| |_| |_|  | For         |
|                                                               | OpenFOAM    |
-------------------------------------------------------------------------------
License
    This file is part of swak4Foam.

    swak4Foam is free software; you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation; either version 2 of the License, or (at your
    option) any later version.

    swak4Foam is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with swak4Foam; if not, write to the Free Software Foundation,
    Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA

Contributors/Copyright:
    2008-2011, 2013, 2015-2018 Bernhard F.W. Gschaider <bgschaid@hfd-research.com>

 SWAK Revision: $Id$
\*---------------------------------------------------------------------------*/

#include "updateSimpleFunctionObject.H"
#include "addToRunTimeSelectionTable.H"

#include "polyMesh.H"
#include "IOmanip.H"
#include "swakTime.H"

// * * * * * * * * * * * * * * Static Data Members * * * * * * * * * * * * * //

namespace Foam
{

    defineTypeNameAndDebug(updateSimpleFunctionObject, 0);

// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

updateSimpleFunctionObject::updateSimpleFunctionObject
(
    const word &name,
    const Time& t,
    const dictionary& dict
)
:
    simpleFunctionObject(name,t,dict)
{
    Pout << "Creating " << name << endl;

    runIfStartTime_=dict_.lookupOrDefault<bool>("runIfStartTime",false);
    onlyAtStartup_=readBool(dict_.lookup("onlyAtStartup"));
    if(onlyAtStartup_) {
        runIfStartTime_=readBool(dict_.lookup("runIfStartTime"));
    }
}

bool updateSimpleFunctionObject::start()
{
    Pbug << "start() started" << endl;
    simpleFunctionObject::start();
    Pbug << "start() called parent" << endl;

    if(onlyAtStartup_) {
        if(
            !runIfStartTime_
            ||
            time().timeIndex()==0
        ) {
            Pbug << "Calling recalc()" << endl;
            recalc();
        }
    }

    Pbug << "start() ended" << endl;

    return true;
}

void updateSimpleFunctionObject::writeSimple()
{
    Pbug << "write() started" << endl;

    if(!onlyAtStartup_) {
        Pbug << "Calling recalc() always" << endl;
        recalc();
    }

    Pbug << "write() ended" << endl;
}

// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

} // namespace Foam

// ************************************************************************* //
